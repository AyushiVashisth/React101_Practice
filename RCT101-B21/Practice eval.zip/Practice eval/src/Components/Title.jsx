// your code goes here
// do a deafult export

const Title = () => {
    return (
      <>
        <h1 style={{ color: "teal" }}>Users Display</h1>
      </>
    );
  };
  export default Title;
  